$(function(){
    $('.personal__account').click(function(evt){
        evt.preventDefault()
        $('.account, .darkening').show()   
    })
    $('.register').click(function(evt){
        evt.preventDefault()
        $('.reg').show()
    })
    $('.close').click(function(evt){
        evt.preventDefault()
        $('.reg').hide()
    })
    $('.close_2').click(function(evt){
        evt.preventDefault()
        $('.account, .darkening').hide()
    })
    $('.korzina').click(function(){
        $('.okno').slideToggle();
        if ($('.okno2').is(':visible')){
            $('.okno2').slideToggle()
        }
    })
    $('.button').click(function(){
        $(this).attr('disabled', true)
        $(this).css({'background':'rgb(10, 42, 42)', 'color': 'white'})
        $(this).text('В корзине')
        var id = $(this).parent().find('.text').text()
        var compound = $(this).parent().find('.text1').text()
        var price = $(this).parent().find('.text__2').text()
        var img = $(this).parent().find('.wrapper__img').attr('src')
        $('.okno').prepend('<article class="art"> <img class="wrapper__img_new" src="'+img+'" width="50px" height="50px"> <div class="text__container"> <p class="new_text">'+id+'</p> <br> <p class="text1">'+compound+'</p> <br> <p class="text__2">'+price+'</p> </div> </arcticle>')
        $('.buy').show()
        $('.pusto').hide()
    })
})